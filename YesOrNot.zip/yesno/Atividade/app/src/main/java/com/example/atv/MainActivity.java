package com.example.atv3110;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private final String URL = "https://yesno.wtf";
    private Retrofit retrofit;

    private Button btnDecidir;

    private EditText txtPergunta;

    private TextView txtResposta;

    private ProgressBar progressBarCEP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtPergunta = findViewById(R.id.txtPergunta);
        txtResposta = findViewById(R.id.txtResposta);
        btnDecidir = findViewById(R.id.btnDecidir);
        progressBarCEP = findViewById(R.id.progressBarCEP);

        progressBarCEP.setVisibility(View.GONE);

        retrofit = new Retrofit.Builder().baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        btnDecidir.setOnClickListener(this);

    }

    public void decidir(){
        String pergunta = txtPergunta.getText().toString().trim();

        RestService restService = retrofit.create(RestService.class);

        Call<YesNo> call = restService.decidir();

        progressBarCEP.setVisibility(View.VISIBLE);

        call.enqueue(new Callback<YesNo>() {
            @Override
            public void onResponse(Call<YesNo> call, Response<YesNo> response) {
                int i = 1;


                if(response.isSuccessful()){
                    YesNo yesNo = response.body();

                    txtResposta.setText(yesNo.getResposta());

                    progressBarCEP.setVisibility(View.GONE);

                }
            }

            @Override
            public void onFailure(Call<YesNo> call, Throwable t) {
            Toast.makeText(getApplicationContext(), "Erro!" + t.getMessage(), Toast.LENGTH_SHORT);
            progressBarCEP.setVisibility(View.GONE);

            }
        });

    }

    @Override
    public void onClick(View v) {

        if(v.getId() == R.id.btnDecidir) {
            decidir();
        }

    }
}