package com.example.atv3110;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class YesNo {

    @SerializedName("answer")
    @Expose
    private String resposta;
    @SerializedName("forced")
    @Expose
    private boolean forcado;
    @SerializedName("image")
    @Expose
    private String imagem;

    public String getResposta() {
        return resposta;
    }

    public void setResposta(String resposta) {
        this.resposta = resposta;
    }

    public boolean isForcado() {
        return forcado;
    }

    public void setForcado(boolean forcado) {
        this.forcado = forcado;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }
}